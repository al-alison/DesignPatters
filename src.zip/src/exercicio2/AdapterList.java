package exercicio2;

import java.util.ArrayList;
import java.util.List;

public class AdapterList{

	public List<Integer> AdapterList(int[] vetor) {
		List<Integer> lista = new ArrayList<>();
		
		for(int i: vetor) {
			lista.add(vetor[i]);
		}
		
		return lista;
		
	}
}
