package exercicio2;

public interface SomadorEsperado {
	int somaVetor(int[] vetor);
}
