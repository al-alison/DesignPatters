package exercicio7_1;

import javax.swing.JOptionPane;

public class TransformReverter extends TransformString{
	
	private String texto;
	@Override
	public void LerString() {
		texto = JOptionPane.showInputDialog("Digite a string: ");	
	}

	@Override
	public void TransformarString() {
		texto = new StringBuilder(texto).reverse().toString();
	}

	@Override
	public void ImprimirString() {
		JOptionPane.showMessageDialog(null, "Texto transformado: "+texto);

	}

}
