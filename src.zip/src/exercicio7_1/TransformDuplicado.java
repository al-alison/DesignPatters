package exercicio7_1;

import javax.swing.JOptionPane;

public class TransformDuplicado extends TransformString{
	
	private String texto;
	@Override
	public void LerString() {
		texto = JOptionPane.showInputDialog("Digite a string: ");	
	}

	@Override
	public void TransformarString() {
		texto = texto+texto;	
	}

	@Override
	public void ImprimirString() {
		JOptionPane.showMessageDialog(null, "Texto transformado: "+texto);

	}

}
