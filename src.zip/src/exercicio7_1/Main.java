package exercicio7_1;

public class Main {

	public static void main(String[] args) {
		
		//TransformString transform = new TransformMinusculo();
		//TransformString transform = new TransformarMaiusculo();
		//TransformString transform = new TransformDuplicado();
		TransformString transform = new TransformReverter();
		transform.RealizarTransformarString();
	}

}
