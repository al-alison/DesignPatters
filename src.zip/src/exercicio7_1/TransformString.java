package exercicio7_1;

public abstract class TransformString {

	public void RealizarTransformarString() {
		LerString();
		TransformarString();
		ImprimirString();
	}

	public abstract void LerString();
	public abstract void TransformarString();
	public abstract void ImprimirString();
}
