package exercicio1;
import java.util.HashMap;

public class HashAdapter{
	
	public HashAdapter(int m[]) 
	{
		HashMap hash = new HashMap();
		hash.put(m[0],m[1]);
	}
}
