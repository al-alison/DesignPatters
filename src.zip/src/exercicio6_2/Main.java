package exercicio6_2;

public class Main {

	public static void main(String[] args) {
		int[] v = {1,2,3,45,5,6,6,6,5,435,435,34,543,5,345,34,534,5};
		
		Ordenacao ordena = new QuickSort();
		ordena.ordenar(v);
		System.out.println("QuickSort");
		for(int i = 0; i<v.length; i++) {
			System.out.println(v[i]);	
		}
		ordena = new SelectionSort();
		ordena.ordenar(v);
		System.out.println("SelectionSort");
		for(int i = 0; i<v.length; i++) {
			System.out.println(v[i]);	
		}
		ordena = new InsertSort();
		ordena.ordenar(v);
		System.out.println("InsertSort");
		for(int i = 0; i<v.length; i++) {
			System.out.println(v[i]);	
		}
		ordena = new BubbleSort();
		ordena.ordenar(v);
		System.out.println("BubbleSort");
		for(int i = 0; i<v.length; i++) {
			System.out.println(v[i]);	
		}
		
		
	}
}
