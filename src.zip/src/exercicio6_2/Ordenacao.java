package exercicio6_2;

public interface Ordenacao {
	
	public int[] ordenar(int v[]);

}
