package exercicio9_1;

public class Main {

	public static void main(String[] args) {			// set slots
			MaquinaCorrente slotMoeda = new Slot100();
			slotMoeda.setNextSlots(new Slot50());
			slotMoeda.setNextSlots(new Slot25());
			slotMoeda.setNextSlots(new Slot10());
			slotMoeda.setNextSlots(new Slot5());
			// select slot
			slotMoeda.setNomeProduto("Doritos");
			slotMoeda.setValorProduto(4.00);
			slotMoeda.setMoedas(5);
			// select the payment form
			try {
				slotMoeda.slotPagamento(Slots.slot5);
				slotMoeda.slotPagamento(Slots.slot10);
				slotMoeda.slotPagamento(Slots.slot25);
				slotMoeda.slotPagamento(Slots.slot50);
				slotMoeda.slotPagamento(Slots.slot100);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}
