package exercicio9_1;

public enum Slots {
	slot5, slot10, slot25, slot50, slot100;
}
