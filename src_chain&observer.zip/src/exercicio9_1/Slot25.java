package exercicio9_1;

public class Slot25 extends MaquinaCorrente{
	
	public Slot25() {
		super(Slots.slot25);
	}

	@Override
	protected double pagar() {
		System.out.println("Slot25: 25 centavos");
		double pagamento = 0.25 * getMoedas();
		double troco = pagamento - getValorProduto();
		if (pagamento == getValorProduto()) {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nsem troco");
		} else {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nTroco:" + troco);
		}
		return pagamento;
	}
}
