package exercicio9_1;

public class Slot50 extends MaquinaCorrente{
	
	public Slot50() {
		super(Slots.slot50);
	}

	@Override
	protected double pagar() {
		System.out.println("Slot50: 50 centavos");
		double pagamento = 0.50 * getMoedas();
		double troco = pagamento - getValorProduto();
		if (pagamento == getValorProduto()) {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nsem troco");
		} else {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nTroco:" + troco);
		}
		return pagamento;
	}
}
