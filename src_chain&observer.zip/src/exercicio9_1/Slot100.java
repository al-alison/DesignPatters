package exercicio9_1;

public class Slot100 extends MaquinaCorrente{
	public Slot100() {
		super(Slots.slot100);
	}

	@Override
	protected double pagar() {
		System.out.println("Slot100: 1 real");
		double pagamento = 1 * getMoedas();
		double troco = pagamento - getValorProduto();
		if (pagamento == getValorProduto()) {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nsem troco");
		} else {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nTroco:" + troco);
		}
		return pagamento;
	}
}
