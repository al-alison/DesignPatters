package exercicio9_1;

public class Slot5 extends MaquinaCorrente {

	public Slot5() {
		super(Slots.slot5);
	}

	@Override
	protected double pagar() {
		System.out.println("Slot5: 5 centavos");
		double pagamento = 0.05 * getMoedas();
		double troco = pagamento - getValorProduto();
		if (pagamento == getValorProduto()) {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nsem troco");
		} else {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nTroco:" + troco);
		}
		return pagamento;
	}

}
