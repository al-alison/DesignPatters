package exercicio9_1;

public class Slot10 extends MaquinaCorrente{

	public Slot10() {
		super(Slots.slot10);
	}

	@Override
	protected double pagar() {
		System.out.println("Slot10: 10 centavos");
		double pagamento = 0.10 * getMoedas();
		double troco = pagamento - getValorProduto();
		if (pagamento == getValorProduto()) {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nsem troco");
		} else {
			System.out.println(
					"Retire seu produto: " + getNomeProduto() + "\nValor:" + getValorProduto() + "\nTroco:" + troco);
		}
		return pagamento;
	}
}
