package exercicio9_1;

public abstract class MaquinaCorrente {
	protected MaquinaCorrente proximoSlot;
	protected Slots slotSelecionado;
	private String nomeProduto;
	private double valorProduto;
	private int moedas;

	protected abstract double pagar();

	public MaquinaCorrente(Slots slots) {
		proximoSlot = null;
		slotSelecionado = slots;
	}

	public MaquinaCorrente getProximoSlot() {
		return proximoSlot;
	}

	public void setProximoSlot(MaquinaCorrente proximoSlot) {
		this.proximoSlot = proximoSlot;
	}

	public Slots getSlotSelecionado() {
		return slotSelecionado;
	}

	public void setSlotSelecionado(Slots slotSelecionado) {
		this.slotSelecionado = slotSelecionado;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public double getValorProduto() {
		return valorProduto;
	}

	public void setValorProduto(double valorProduto) {
		this.valorProduto = valorProduto;
	}

	public int getMoedas() {
		return moedas;
	}

	public void setMoedas(int moedas) {
		this.moedas = moedas;
	}

	public boolean isSlot(Slots slots) {
		if (slotSelecionado == slots) {
			return true;
		}
		return false;
	}

	public void slotPagamento(Slots slots) throws Exception {
		if (isSlot(slots)) {
			pagar();
		} else {
			if (proximoSlot == null) {
				throw new Exception("invalid slot");
			}
			proximoSlot.slotPagamento(slots);
		}
	}


	public void setNextSlots(MaquinaCorrente next) {
		if (proximoSlot == null) {
			proximoSlot = next;
		} else {
			proximoSlot.setNextSlots(next);
		}
	}

}
