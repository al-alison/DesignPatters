package exercicio8_1;

import java.util.Observer;

public interface ConsomeNoticia extends Observer{
	
public void notificaNoticia(String textoNoticia, int dia,
       int mes, String topico);
}