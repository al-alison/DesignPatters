package exercicio8_1;

public class Main {

	public static void main(String[] args) {
		NoticiarioAssina not = new NoticiarioAssina();
		not.notificaNoticia("Noticia X", 03, 04, "Indefinido");
		@SuppressWarnings("unused")
		Consumidor c = new Consumidor(not);
		not.notificaNoticia("Noticia Y", 04, 04, "Definido");
		not.notificaNoticia("Noticia Z", 05, 07, "Definido de novo");
	}
}
