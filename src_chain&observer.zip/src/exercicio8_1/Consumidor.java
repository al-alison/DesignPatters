package exercicio8_1;

import java.util.Observable;

public class Consumidor implements ConsomeNoticia{
	
	Observable NoticiarioAss;
		
	public Consumidor(Observable NoticiarioAss) {
		this.NoticiarioAss = NoticiarioAss;
		NoticiarioAss.addObserver(this);
	}
	
	@Override
	public void update(Observable o, Object arg) {
		if (NoticiarioAss instanceof NoticiarioAssina) {
			NoticiarioAssina noticia = (NoticiarioAssina) NoticiarioAss;
			notificaNoticia(noticia.getTextoNoticia(), noticia.getDia(), noticia.getMes(), noticia.getTopico());
		}
		
	}

	@Override
	public void notificaNoticia(String textoNoticia, int dia, int mes, String topico) {
		System.out.println("Nova noticia: "+textoNoticia+" Dia: "+dia+" Mes: "+mes+" Topico: "+topico);
	}

}
